=== Prolo for WordPress ===
Contributors: John Vitelli, David Roach, Jonathan Cooper, Jordan Schibler
Tags: prolo, product locator, finder, products, prolo finder
Requires at least: 3.0
Tested up to: 1.0
Stable tag: 1.0
License: GPLv2 or later

Prolo is the best way to add a product finder to your website.
Prolo for WordPress gives users the ability to seamlessly embed their finder to any post or page.

== Description ==

Your Products. Found.
Prolo is the best way to add a product finder to your website.
No matter what you call it, Prolo helps your customers find your products. In just a few minutes, you can have a searchable product finder running on your website.



== Installation ==

Upload the Prolo Finder plugin to your blog, Activate it, then copy and paste our shortcode, with your Prolo Finder Key... and done!


== Changelog ==

= 1.0 =
Gives users the ability to add a prolofinder embed using WP's inbound shortcode API