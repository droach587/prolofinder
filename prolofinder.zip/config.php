<h1><img src="<?php echo plugins_url(); ?>/prolofinder/img/prolo-brand.svg" width="w0" height="20"> Prolo for Wordpress</h1>
<p>Thanks for choosing Prolo as your product finder/store locator. Please follow the simple steps below to add your Prolo finder to any post or page in WordPress!</p>
<p><a class="button button-primary" target="_blank" href="http://prolofinder.uservoice.com/">Prolo Support</a> <a class="button button-primary" target="_blank" href="http://prolofinder.com">Prolo Homepage</a> <a class="button button-primary" target="_blank" href="http://prolofinder.com/login">Prolo Login</a></p>
<hr>
<h3>This plugin will activate a WordPress shortcode which you can use anywhere to embed your Prolo finder. </h3>
<p>Custom Shortcode: <strong>[prolofinder key="YOUR_FINDER_KEY"]</strong></p>
<hr/>
<h2>Getting Started Guide</h2>
<hr/>
<h3>Log in to Prolo</h3>
<hr/>
<p>Please visit your <a class="button button-primary" target="_blank" href="http://www.prolofinder.com/login">Prolo Dashboard</a> and locate the <strong>Set Up</strong> tab.</p>
<p><img src="<?php echo plugins_url(); ?>/prolofinder/img/prolo-setup.jpg"></p>
<hr/>
<h3>Locate your "Finder Key"</h3>
<hr/>
<p>A Finder Key is a numerical value which represents your finder. This key is used to embed your custom Prolo finder on your webpage. We'll need to locate this value in order to embed Prolo on WordPress.</p>
<p>Within the <strong>Set UP</strong> tab, you should see a text-box under the term <strong>Add To Your Site</strong>. This box contains your finder's embed code. At the end of that code is a number that may look something like: <strong>collection=xxxxxx</strong>.</p>
<p>Your <strong>Finder Key</strong> is the numerical value just after the term "<strong>collection=</strong>".</p>
<p><img src="<?php echo plugins_url(); ?>/prolofinder/img/prolo-collection-id.jpg"></p>
<hr/>
<h3>Copy your "Finder Key"</h3>
<hr/>
<p>Copy your Finder Key (<em>command+c (mac), ctrl+c (pc)</em>) and add it to our custom shortcode.</p>
<p>Replacing "YOUR_FINDER_KEY" with what you've just copied. Example: <strong>[prolofinder key="47680100"]</strong></p>
<hr/>
<h3>Insert Into a Page or Post</h3>
<hr/>
<p>Once you've updated the shortcode, simply copy and paste that code in any page or post in simple plain-text and hit publish!<br>You will now see your newly minted Prolo finder on your page or post.</p>
<p><img src="<?php echo plugins_url(); ?>/prolofinder/img/prolo-post.jpg"></p>
<hr/>
<h2>Help, Support and Feedback</h2>
<p>If you're experiencing any trouble embedding Prolo on WordPress, or would like to send us your feedback <a class="button button-primary" target="_blank" href="http://prolofinder.uservoice.com/">Visit Our Support Page</a>.</p>
<hr/>